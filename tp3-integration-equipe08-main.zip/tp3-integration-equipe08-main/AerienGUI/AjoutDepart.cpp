/**
 * \file AjoutDepart.cpp
 * \brief Implantation de la classe AjoutDepart
 * \author Rosalie Tremblay
 * \date 30 juin 2024, 18 h 32
 */

#include <QMessageBox>
#include <qt5/QtWidgets/qdialog.h>
#include "AjoutDepart.h"
#include "validationFormat.h"

/**
 * \brief Constructeur par défaut
 *        Un objet AjoutDepart est construit par défaut sans paramètres.
 */
AjoutDepart::AjoutDepart ()
{
  widget.setupUi (this);
}

/**
 * \brief Accesseur pour le numéro de vol
 * \return Une chaine de caractères correspondant au numéro de vol entré dans l'interface graphique
 */
std::string AjoutDepart::reqNumero() const
{
  return widget.ligne_num_vol->text ().toStdString();
}

/**
 * \brief Accesseur pour le nom de la compagnie
 * \return Une chaine de caractères correspondant au nom de la compagnie entré dans l'interface graphique
 */
std::string AjoutDepart::reqCompagnie() const
{
  return widget.ligne_compagnie->text ().toStdString();
}

/**
 * \brief Accesseur pour l'heure de départ ou d'arrivée
 * \return Une chaine de caractères correspondant à l'heure entrée dans l'interface graphique
 */
std::string AjoutDepart::reqHeure() const
{
  return widget.ligne_heure->text ().toStdString();
}

/**
 * \brief Accesseur pour le nom de la ville
 * \return Une chaine de caractères correspondant au nom de la ville entré dans l'interface graphique
 */
std::string AjoutDepart::reqVille() const
{
  return widget.ligne_ville->text ().toStdString();
}

/**
 * \brief Accesseur pour l'heure d'embarquement
 * \return Une chaine de caractères correspondant à l'heure entrée dans l'interface graphique
 */
std::string AjoutDepart::reqEmbarq() const
{
  return widget.ligne_heure_embarq->text ().toStdString();
}

/**
 * \brief Accesseur pour la porte d'embarquement
 * \return Une chaine de caractères correspondant au numéro de porte entré dans l'interface graphique
 */
std::string AjoutDepart::reqPorte() const
{
  return widget.ligne_porte->text ().toStdString();
}

/**
 * \brief Vérifie la validité des données entrées par l'utilisateur
 */
void AjoutDepart::slotConfirmerDepart()
{
//Vérifier tous les champs
//Si un champ n'a pas format valide: message box
  if(!util::estNumeroVolValide (reqNumero()))
    {
      QString message ("Le numéro de vol n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estNomValide (reqCompagnie()))
    {
      QString message ("Le nom de la compagnie n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estFormat24HValide (reqHeure()))
    {
      QString message ("L'heure de décollage n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estNomValide (reqVille()))
    {
      QString message ("Le nom de la ville n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estFormat24HValide (reqEmbarq()))
    {
      QString message ("L'heure d'embarquement n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(reqEmbarq()>reqHeure())
    {
      QString message ("L'heure d'embarquement ne peut pas être plus grande que l'heure de décollage.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estPorteValide (reqPorte()))
    {
      QString message ("Le numéro de porte n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  
  accept();

}

/**
 * \brief Destructeur de la classe AjoutDepart
 */
AjoutDepart::~AjoutDepart () { }