/********************************************************************************
** Form generated from reading UI file 'TableauAeroport.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLEAUAEROPORT_H
#define UI_TABLEAUAEROPORT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TableauAeroport
{
public:
    QAction *actionSupprimer_un_vol;
    QAction *actionQuitter;
    QAction *actionDepart;
    QAction *actionArrivee;
    QWidget *centralwidget;
    QTextEdit *textEditAero;
    QMenuBar *menubar;
    QMenu *menuMenu;
    QMenu *menuAjouter_un_vol;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TableauAeroport)
    {
        if (TableauAeroport->objectName().isEmpty())
            TableauAeroport->setObjectName(QString::fromUtf8("TableauAeroport"));
        TableauAeroport->resize(689, 584);
        actionSupprimer_un_vol = new QAction(TableauAeroport);
        actionSupprimer_un_vol->setObjectName(QString::fromUtf8("actionSupprimer_un_vol"));
        actionQuitter = new QAction(TableauAeroport);
        actionQuitter->setObjectName(QString::fromUtf8("actionQuitter"));
        actionDepart = new QAction(TableauAeroport);
        actionDepart->setObjectName(QString::fromUtf8("actionDepart"));
        actionArrivee = new QAction(TableauAeroport);
        actionArrivee->setObjectName(QString::fromUtf8("actionArrivee"));
        centralwidget = new QWidget(TableauAeroport);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        textEditAero = new QTextEdit(centralwidget);
        textEditAero->setObjectName(QString::fromUtf8("textEditAero"));
        textEditAero->setGeometry(QRect(13, 34, 661, 521));
        textEditAero->setStyleSheet(QString::fromUtf8("font: 10pt \"Monospace\";"));
        TableauAeroport->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TableauAeroport);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 689, 22));
        menuMenu = new QMenu(menubar);
        menuMenu->setObjectName(QString::fromUtf8("menuMenu"));
        menuAjouter_un_vol = new QMenu(menuMenu);
        menuAjouter_un_vol->setObjectName(QString::fromUtf8("menuAjouter_un_vol"));
        TableauAeroport->setMenuBar(menubar);
        statusbar = new QStatusBar(TableauAeroport);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        TableauAeroport->setStatusBar(statusbar);

        menubar->addAction(menuMenu->menuAction());
        menuMenu->addAction(menuAjouter_un_vol->menuAction());
        menuMenu->addAction(actionSupprimer_un_vol);
        menuMenu->addAction(actionQuitter);
        menuAjouter_un_vol->addAction(actionDepart);
        menuAjouter_un_vol->addAction(actionArrivee);

        retranslateUi(TableauAeroport);
        QObject::connect(actionQuitter, SIGNAL(triggered()), TableauAeroport, SLOT(close()));
        QObject::connect(actionDepart, SIGNAL(triggered()), TableauAeroport, SLOT(slotAjoutDepart()));
        QObject::connect(actionArrivee, SIGNAL(triggered()), TableauAeroport, SLOT(slotAjoutArrivee()));
        QObject::connect(actionSupprimer_un_vol, SIGNAL(triggered()), TableauAeroport, SLOT(slotSupprimerVol()));

        QMetaObject::connectSlotsByName(TableauAeroport);
    } // setupUi

    void retranslateUi(QMainWindow *TableauAeroport)
    {
        TableauAeroport->setWindowTitle(QCoreApplication::translate("TableauAeroport", "TableauAeroport", nullptr));
        actionSupprimer_un_vol->setText(QCoreApplication::translate("TableauAeroport", "Supprimer un vol", nullptr));
        actionQuitter->setText(QCoreApplication::translate("TableauAeroport", "Quitter", nullptr));
        actionDepart->setText(QCoreApplication::translate("TableauAeroport", "D\303\251part", nullptr));
        actionArrivee->setText(QCoreApplication::translate("TableauAeroport", "Arriv\303\251e", nullptr));
        menuMenu->setTitle(QCoreApplication::translate("TableauAeroport", "Operations", nullptr));
        menuAjouter_un_vol->setTitle(QCoreApplication::translate("TableauAeroport", "Ajouter un vol", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TableauAeroport: public Ui_TableauAeroport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLEAUAEROPORT_H
