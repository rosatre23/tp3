/**
 * \file AjoutArrivee.cpp
 * \brief Implantation de la classe AjoutArrivee
 * \author Rosalie Tremblay
 * \date 10 juillet 2024, 18 h 03
 */

#include <QMessageBox>
#include <qt5/QtWidgets/qdialog.h>
#include "validationFormat.h"
#include "AjoutArrivee.h"

using namespace std;

/**
 * \brief Constructeur par défaut
 *        Un objet AjoutArrivee est construit par défaut sans paramètres.
 */
AjoutArrivee::AjoutArrivee ()
{
  widget.setupUi (this);
}

/**
 * \brief Accesseur pour le numéro de vol
 * \return Une chaine de caractères correspondant au numéro de vol entré dans l'interface graphique
 */
std::string AjoutArrivee::reqNumero() const
{
  return widget.lineEditNum->text().toStdString();
}

/**
 * \brief Accesseur pour le nom de la compagnie
 * \return Une chaine de caractères correspondant au nom de la compagnie entré dans l'interface graphique
 */
std::string AjoutArrivee::reqCompagnie() const
{
  return widget.lineEditCompagnie->text ().toStdString();
}

/**
 * \brief Accesseur pour l'heure de départ ou d'arrivée
 * \return Une chaine de caractères correspondant à l'heure entrée dans l'interface graphique
 */
std::string AjoutArrivee::reqHeure() const
{
  return widget.lineEditHeure->text ().toStdString();
}

/**
 * \brief Accesseur pour le nom de la ville
 * \return Une chaine de caractères correspondant au nom de la ville entré dans l'interface graphique
 */
std::string AjoutArrivee::reqVille() const
{
  return widget.lineEditVille->text ().toStdString();
}

/**
 * \brief Accesseur pour le statut
 * \return Une chaine de caractères correspondant au statut entré dans l'interface graphique
 */
std::string AjoutArrivee::reqStatut() const
{
  string statut = widget.lineEditStatut->text ().toStdString();
  if (statut=="Atterri")
    {
      statut = util::ajusterLargeur (statut,9);
    }
  if (statut=="Retardé" || statut == "À l'heure")
    {
      statut = util::ajusterLargeur (statut,10);
    }
  
  return statut;
}

/**
 * \brief Vérifie la validité des données entrées par l'utilisateur
 */
void AjoutArrivee::slotConfirmerArrivee()
{
  
//Vérifier tous les champs
//Si un champ n'a pas format valide: message box
  if(!util::estNumeroVolValide (reqNumero()))
    {
      QString message ("Le numéro de vol n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estNomValide (reqCompagnie()))
    {
      QString message ("Le nom de la compagnie n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estFormat24HValide (reqHeure()))
    {
      QString message ("L'heure de décollage n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(!util::estNomValide (reqVille()))
    {
      QString message ("Le nom de la ville n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  if(reqStatut()!=" Atterri " && reqStatut()!=" Retardé " && reqStatut()!="À l'heure")
    {
      QString message ("Le statut n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  
  accept();

}

/**
 * \brief Destructeur de la classe AjoutArrivee
 */
AjoutArrivee::~AjoutArrivee () { }
