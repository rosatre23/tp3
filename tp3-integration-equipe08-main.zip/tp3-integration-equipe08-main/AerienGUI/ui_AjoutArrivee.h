/********************************************************************************
** Form generated from reading UI file 'AjoutArrivee.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTARRIVEE_H
#define UI_AJOUTARRIVEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AjoutArrivee
{
public:
    QLabel *labelNumero;
    QLabel *labelCompagnie;
    QLabel *labelHeure;
    QLabel *labelVille;
    QLabel *labelStatut;
    QLineEdit *lineEditNum;
    QLineEdit *lineEditCompagnie;
    QLineEdit *lineEditHeure;
    QLineEdit *lineEditVille;
    QLineEdit *lineEditStatut;
    QPushButton *ButtonConfirmerArrivee;

    void setupUi(QDialog *AjoutArrivee)
    {
        if (AjoutArrivee->objectName().isEmpty())
            AjoutArrivee->setObjectName(QString::fromUtf8("AjoutArrivee"));
        AjoutArrivee->resize(386, 336);
        labelNumero = new QLabel(AjoutArrivee);
        labelNumero->setObjectName(QString::fromUtf8("labelNumero"));
        labelNumero->setGeometry(QRect(60, 50, 121, 16));
        labelCompagnie = new QLabel(AjoutArrivee);
        labelCompagnie->setObjectName(QString::fromUtf8("labelCompagnie"));
        labelCompagnie->setGeometry(QRect(80, 90, 91, 16));
        labelHeure = new QLabel(AjoutArrivee);
        labelHeure->setObjectName(QString::fromUtf8("labelHeure"));
        labelHeure->setGeometry(QRect(110, 130, 58, 16));
        labelVille = new QLabel(AjoutArrivee);
        labelVille->setObjectName(QString::fromUtf8("labelVille"));
        labelVille->setGeometry(QRect(120, 170, 58, 16));
        labelStatut = new QLabel(AjoutArrivee);
        labelStatut->setObjectName(QString::fromUtf8("labelStatut"));
        labelStatut->setGeometry(QRect(110, 210, 58, 16));
        lineEditNum = new QLineEdit(AjoutArrivee);
        lineEditNum->setObjectName(QString::fromUtf8("lineEditNum"));
        lineEditNum->setGeometry(QRect(210, 47, 113, 21));
        lineEditCompagnie = new QLineEdit(AjoutArrivee);
        lineEditCompagnie->setObjectName(QString::fromUtf8("lineEditCompagnie"));
        lineEditCompagnie->setGeometry(QRect(210, 90, 113, 21));
        lineEditHeure = new QLineEdit(AjoutArrivee);
        lineEditHeure->setObjectName(QString::fromUtf8("lineEditHeure"));
        lineEditHeure->setGeometry(QRect(210, 130, 113, 21));
        lineEditVille = new QLineEdit(AjoutArrivee);
        lineEditVille->setObjectName(QString::fromUtf8("lineEditVille"));
        lineEditVille->setGeometry(QRect(210, 170, 113, 21));
        lineEditStatut = new QLineEdit(AjoutArrivee);
        lineEditStatut->setObjectName(QString::fromUtf8("lineEditStatut"));
        lineEditStatut->setGeometry(QRect(210, 210, 113, 21));
        ButtonConfirmerArrivee = new QPushButton(AjoutArrivee);
        ButtonConfirmerArrivee->setObjectName(QString::fromUtf8("ButtonConfirmerArrivee"));
        ButtonConfirmerArrivee->setGeometry(QRect(140, 270, 90, 28));

        retranslateUi(AjoutArrivee);
        QObject::connect(ButtonConfirmerArrivee, SIGNAL(clicked()), AjoutArrivee, SLOT(slotConfirmerArrivee()));

        QMetaObject::connectSlotsByName(AjoutArrivee);
    } // setupUi

    void retranslateUi(QDialog *AjoutArrivee)
    {
        AjoutArrivee->setWindowTitle(QCoreApplication::translate("AjoutArrivee", "AjoutArrivee", nullptr));
        labelNumero->setText(QCoreApplication::translate("AjoutArrivee", "Num\303\251ro de vol :", nullptr));
        labelCompagnie->setText(QCoreApplication::translate("AjoutArrivee", "Compagnie :", nullptr));
        labelHeure->setText(QCoreApplication::translate("AjoutArrivee", "Heure :", nullptr));
        labelVille->setText(QCoreApplication::translate("AjoutArrivee", "Ville :", nullptr));
        labelStatut->setText(QCoreApplication::translate("AjoutArrivee", "Statut :", nullptr));
        lineEditNum->setText(QCoreApplication::translate("AjoutArrivee", "LH0472", nullptr));
        lineEditCompagnie->setText(QCoreApplication::translate("AjoutArrivee", "LUFTHANSA", nullptr));
        lineEditHeure->setText(QCoreApplication::translate("AjoutArrivee", "22:05", nullptr));
        lineEditVille->setText(QCoreApplication::translate("AjoutArrivee", "MUNICH", nullptr));
        lineEditStatut->setText(QCoreApplication::translate("AjoutArrivee", "Retard\303\251", nullptr));
        ButtonConfirmerArrivee->setText(QCoreApplication::translate("AjoutArrivee", "Confirmer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjoutArrivee: public Ui_AjoutArrivee {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTARRIVEE_H
