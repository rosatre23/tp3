/**
 * \file AjoutArrivee.h
 * \brief Fichier contenant la déclaration de la classe AjoutArrivee
 * \author Rosalie Tremblay
 * \date 10 juillet 2024, 18 h 03
 */


#ifndef _AJOUTARRIVEE_H
#define _AJOUTARRIVEE_H

#include "ui_AjoutArrivee.h"

class AjoutArrivee : public QDialog
{
  Q_OBJECT
public:
  AjoutArrivee ();
  
  std::string reqNumero() const;
  std::string reqCompagnie() const;
  std::string reqHeure() const;
  std::string reqVille() const;
  std::string reqStatut() const;
  
  virtual ~AjoutArrivee ();
  
  private slots:
    void slotConfirmerArrivee();
  
private:
  Ui::AjoutArrivee widget;
};

#endif /* _AJOUTARRIVEE_H */
