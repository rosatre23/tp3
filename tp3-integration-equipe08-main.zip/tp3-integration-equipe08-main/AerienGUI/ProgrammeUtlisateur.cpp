/**
 * \file ProgrammeUtilisateur.cpp
 * \brief Interface utilisateur pour la construction d'aéroports
 * \author Rosalie Tremblay
 * \date 30 juin 2024, 17 h 32
 */

#include "TableauAeroport.h"
#include <QApplication>
#include "Aeroport.h"

/**
 * \fn int main(int argc, char *argv[])
 * \brief Permet l'ouverture de la fenêtre principale permettant
 *        la création d'un aéroport par un utilisateur
 */
int main (int argc, char *argv[])
{
  // initialize resources, if needed
  // Q_INIT_RESOURCE(resfile);

  QApplication app (argc, argv);
  TableauAeroport tableau;
  tableau.show(); //Ouverture de la fenêtre principale

  return app.exec ();
}
