/**
 * \file TableauAeroport.h
 * \brief Fichier contenant la déclaration de la classe TableauAeroport
 * \author Rosalie Tremblay
 * \date 30 juin 2024, 17 h 37
 */

#ifndef _TABLEAUAEROPORT_H
#define _TABLEAUAEROPORT_H
#include "Aeroport.h"
#include "ui_TableauAeroport.h"

class TableauAeroport : public QMainWindow
{
  Q_OBJECT
  
public:
  TableauAeroport ();
  virtual ~TableauAeroport ();
  
  private slots:
    void slotAjoutDepart();
    void slotAjoutArrivee();
    void slotSupprimerVol();
  
private:
  Ui::TableauAeroport widget;
  aerien::Aeroport m_aero;
};

#endif /* _TABLEAUAEROPORT_H */
