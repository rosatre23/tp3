/**
 * \file SupprimerVol.cpp
 * \brief Implantation de la classe SupprimerVol
 * \author Rosalie Tremblay
 * \date 13 juillet 2024, 16 h 19
 */

#include <QMessageBox>
#include <qt5/QtWidgets/qdialog.h>
#include "validationFormat.h"
#include "SupprimerVol.h"

/**
 * \brief Constructeur par défaut
 *        Un objet SupprimerVol est construit par défaut sans paramètres.
 */
SupprimerVol::SupprimerVol ()
{
  widget.setupUi (this);
}

/**
 * \brief Accesseur pour le numéro de vol
 * \return Une chaine de caractères correspondant au numéro de vol entré dans l'interface graphique
 */
std::string SupprimerVol::reqNumero() const
{
  return widget.lineEditNumSup->text ().toStdString();
}

/**
 * \brief Vérifie la validité du numéro de vol entré par l'utilisateur
 */
void SupprimerVol::slotConfirmerSupp()
{
  if(!util::estNumeroVolValide (reqNumero()))
    {
      QString message ("Le numéro de vol n'est pas valide.");
      QMessageBox::information(this,"Erreur",message);
      return;
    }
  accept();
}

/**
 * \brief Destructeur de la classe SupprimerVol
 */
SupprimerVol::~SupprimerVol () { }
