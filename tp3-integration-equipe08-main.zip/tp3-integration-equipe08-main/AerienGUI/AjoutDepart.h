/**
 * \file AjoutDepart.h
 * \brief Fichier contenant la déclaration de la classe AjoutDepart
 * \author Rosalie Tremblay
 * \date 30 juin 2024, 18 h 32
 */

#ifndef _AJOUTDEPART_H
#define _AJOUTDEPART_H

#include "ui_AjoutDepart.h"

class AjoutDepart : public QDialog
{
  Q_OBJECT
public:
  AjoutDepart ();
  std::string reqNumero() const;
  std::string reqCompagnie() const;
  std::string reqHeure() const;
  std::string reqVille() const;
  std::string reqPorte() const;
  std::string reqEmbarq() const;

  virtual ~AjoutDepart ();
  
private slots:
  void slotConfirmerDepart();
  
private:
  Ui::AjoutDepart widget;
};

#endif /* _AJOUTDEPART_H */
