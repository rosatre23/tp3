/**
 * \file SupprimerVol.h
 * \brief Fichier contenant la déclaration de la classe SupprimerVol
 * \author Rosalie Tremblay
 * \date 13 juillet 2024, 16 h 19
 */

#ifndef _SUPPRIMERVOL_H
#define _SUPPRIMERVOL_H

#include "ui_SupprimerVol.h"

class SupprimerVol : public QDialog
{
  Q_OBJECT
  
public:
  SupprimerVol ();
  std::string reqNumero() const;
  virtual ~SupprimerVol ();
  
  private slots:
    void slotConfirmerSupp();
  
private:
  Ui::SupprimerVol widget;
};

#endif /* _SUPPRIMERVOL_H */
