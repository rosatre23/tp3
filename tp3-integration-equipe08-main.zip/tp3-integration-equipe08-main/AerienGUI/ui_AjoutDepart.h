/********************************************************************************
** Form generated from reading UI file 'AjoutDepart.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTDEPART_H
#define UI_AJOUTDEPART_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AjoutDepart
{
public:
    QPushButton *BoutonConfirmerDepart;
    QLabel *Num_vol;
    QLineEdit *ligne_num_vol;
    QLabel *Compagnie;
    QLineEdit *ligne_compagnie;
    QLineEdit *ligne_heure;
    QLabel *Heure;
    QLineEdit *ligne_ville;
    QLabel *Ville;
    QLabel *Porte;
    QLabel *Heure_embarq;
    QLineEdit *ligne_porte;
    QLineEdit *ligne_heure_embarq;

    void setupUi(QDialog *AjoutDepart)
    {
        if (AjoutDepart->objectName().isEmpty())
            AjoutDepart->setObjectName(QString::fromUtf8("AjoutDepart"));
        AjoutDepart->resize(389, 360);
        BoutonConfirmerDepart = new QPushButton(AjoutDepart);
        BoutonConfirmerDepart->setObjectName(QString::fromUtf8("BoutonConfirmerDepart"));
        BoutonConfirmerDepart->setGeometry(QRect(140, 300, 90, 28));
        Num_vol = new QLabel(AjoutDepart);
        Num_vol->setObjectName(QString::fromUtf8("Num_vol"));
        Num_vol->setGeometry(QRect(80, 40, 101, 16));
        ligne_num_vol = new QLineEdit(AjoutDepart);
        ligne_num_vol->setObjectName(QString::fromUtf8("ligne_num_vol"));
        ligne_num_vol->setGeometry(QRect(200, 40, 113, 21));
        Compagnie = new QLabel(AjoutDepart);
        Compagnie->setObjectName(QString::fromUtf8("Compagnie"));
        Compagnie->setGeometry(QRect(100, 80, 101, 16));
        ligne_compagnie = new QLineEdit(AjoutDepart);
        ligne_compagnie->setObjectName(QString::fromUtf8("ligne_compagnie"));
        ligne_compagnie->setGeometry(QRect(200, 80, 113, 21));
        ligne_heure = new QLineEdit(AjoutDepart);
        ligne_heure->setObjectName(QString::fromUtf8("ligne_heure"));
        ligne_heure->setGeometry(QRect(200, 120, 113, 21));
        Heure = new QLabel(AjoutDepart);
        Heure->setObjectName(QString::fromUtf8("Heure"));
        Heure->setGeometry(QRect(130, 120, 101, 16));
        ligne_ville = new QLineEdit(AjoutDepart);
        ligne_ville->setObjectName(QString::fromUtf8("ligne_ville"));
        ligne_ville->setGeometry(QRect(200, 160, 113, 21));
        Ville = new QLabel(AjoutDepart);
        Ville->setObjectName(QString::fromUtf8("Ville"));
        Ville->setGeometry(QRect(140, 160, 101, 16));
        Porte = new QLabel(AjoutDepart);
        Porte->setObjectName(QString::fromUtf8("Porte"));
        Porte->setGeometry(QRect(130, 200, 41, 16));
        Heure_embarq = new QLabel(AjoutDepart);
        Heure_embarq->setObjectName(QString::fromUtf8("Heure_embarq"));
        Heure_embarq->setGeometry(QRect(20, 240, 151, 16));
        ligne_porte = new QLineEdit(AjoutDepart);
        ligne_porte->setObjectName(QString::fromUtf8("ligne_porte"));
        ligne_porte->setGeometry(QRect(200, 200, 113, 21));
        ligne_heure_embarq = new QLineEdit(AjoutDepart);
        ligne_heure_embarq->setObjectName(QString::fromUtf8("ligne_heure_embarq"));
        ligne_heure_embarq->setGeometry(QRect(200, 240, 113, 21));

        retranslateUi(AjoutDepart);
        QObject::connect(BoutonConfirmerDepart, SIGNAL(clicked()), AjoutDepart, SLOT(slotConfirmerDepart()));

        QMetaObject::connectSlotsByName(AjoutDepart);
    } // setupUi

    void retranslateUi(QDialog *AjoutDepart)
    {
        AjoutDepart->setWindowTitle(QCoreApplication::translate("AjoutDepart", "AjoutDepart", nullptr));
        BoutonConfirmerDepart->setText(QCoreApplication::translate("AjoutDepart", "Confirmer", nullptr));
        Num_vol->setText(QCoreApplication::translate("AjoutDepart", "Num\303\251ro de vol :", nullptr));
        ligne_num_vol->setText(QCoreApplication::translate("AjoutDepart", "AC1636", nullptr));
        Compagnie->setText(QCoreApplication::translate("AjoutDepart", "Compagnie :", nullptr));
        ligne_compagnie->setText(QCoreApplication::translate("AjoutDepart", "AIR CANADA", nullptr));
        ligne_heure->setText(QCoreApplication::translate("AjoutDepart", "17:00", nullptr));
        Heure->setText(QCoreApplication::translate("AjoutDepart", "Heure :", nullptr));
        ligne_ville->setText(QCoreApplication::translate("AjoutDepart", "QUEBEC", nullptr));
        Ville->setText(QCoreApplication::translate("AjoutDepart", "Ville :", nullptr));
        Porte->setText(QCoreApplication::translate("AjoutDepart", "Porte :", nullptr));
        Heure_embarq->setText(QCoreApplication::translate("AjoutDepart", "Heure d'embarquement :", nullptr));
        ligne_porte->setText(QCoreApplication::translate("AjoutDepart", "E50", nullptr));
        ligne_heure_embarq->setText(QCoreApplication::translate("AjoutDepart", "16:30", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjoutDepart: public Ui_AjoutDepart {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTDEPART_H
