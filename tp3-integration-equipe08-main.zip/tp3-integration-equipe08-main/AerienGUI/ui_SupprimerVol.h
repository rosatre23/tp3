/********************************************************************************
** Form generated from reading UI file 'SupprimerVol.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPRIMERVOL_H
#define UI_SUPPRIMERVOL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SupprimerVol
{
public:
    QLabel *labelNumeroSup;
    QLineEdit *lineEditNumSup;
    QPushButton *pushButtonConfirmerSup;

    void setupUi(QDialog *SupprimerVol)
    {
        if (SupprimerVol->objectName().isEmpty())
            SupprimerVol->setObjectName(QString::fromUtf8("SupprimerVol"));
        SupprimerVol->resize(493, 201);
        labelNumeroSup = new QLabel(SupprimerVol);
        labelNumeroSup->setObjectName(QString::fromUtf8("labelNumeroSup"));
        labelNumeroSup->setGeometry(QRect(50, 60, 191, 16));
        lineEditNumSup = new QLineEdit(SupprimerVol);
        lineEditNumSup->setObjectName(QString::fromUtf8("lineEditNumSup"));
        lineEditNumSup->setGeometry(QRect(270, 50, 151, 28));
        pushButtonConfirmerSup = new QPushButton(SupprimerVol);
        pushButtonConfirmerSup->setObjectName(QString::fromUtf8("pushButtonConfirmerSup"));
        pushButtonConfirmerSup->setGeometry(QRect(200, 140, 90, 28));

        retranslateUi(SupprimerVol);
        QObject::connect(pushButtonConfirmerSup, SIGNAL(clicked()), SupprimerVol, SLOT(slotConfirmerSupp()));

        QMetaObject::connectSlotsByName(SupprimerVol);
    } // setupUi

    void retranslateUi(QDialog *SupprimerVol)
    {
        SupprimerVol->setWindowTitle(QCoreApplication::translate("SupprimerVol", "SupprimerVol", nullptr));
        labelNumeroSup->setText(QCoreApplication::translate("SupprimerVol", "Num\303\251ro du vol \303\240 supprimer :", nullptr));
        lineEditNumSup->setText(QCoreApplication::translate("SupprimerVol", "AC1636", nullptr));
        pushButtonConfirmerSup->setText(QCoreApplication::translate("SupprimerVol", "Confirmer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SupprimerVol: public Ui_SupprimerVol {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPRIMERVOL_H
