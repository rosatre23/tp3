/**
 * \file TableauAeroport.cpp
 * \brief Implantation de la classe TableauAeroport
 * \author Rosalie Tremblay
 * \date 30 juin 2024, 17 h 37
 */

#include <QMessageBox>
#include <qt5/QtWidgets/qdialog.h>
#include "TableauAeroport.h"
#include "AjoutDepart.h"
#include "AjoutArrivee.h"
#include "VolException.h"
#include "SupprimerVol.h"

using namespace std;
using namespace aerien;

/**
 * \brief Constructeur par défaut
 *        Un objet TableauAeroport est construit par défaut sans paramètres.
 *        Le code "YUL" et plusieurs vols lui sont attribués.
 */
TableauAeroport::TableauAeroport (): m_aero("YUL")
{
  m_aero.ajouterVol(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH"," Retardé "));
  m_aero.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  m_aero.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  m_aero.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  m_aero.ajouterVol(Depart("AF0345","AIR FRANCE","17:00","PARIS","16:15","E50"));
  m_aero.ajouterVol(Depart("BA0094","BRITISH AIRWAYS","22:15","LONDRES","21:30","A57"));
  m_aero.ajouterVol(Depart("QR0764","QATAR AIRWAYS","21:35","DOHA","21:00","A55"));
  m_aero.ajouterVol(Arrivee("WS0214","WESTJEST","00:34","CALGARY","À l'heure"));
  m_aero.ajouterVol(Depart("TS0820","AIR TRANSAT","06:45","ATLANTA","06:00","C85"));
  m_aero.ajouterVol(Arrivee("AC0424","AIR CANADA","20:41","TORONTO"," Atterri "));
  m_aero.ajouterVol(Depart("WG6544","SUNWING","07:00","CAYO COCO","06:30","A59"));
  m_aero.ajouterVol(Arrivee("UA3647","UNITED AIRLINES","21:06","CHIGAGO","À l'heure"));
  m_aero.ajouterVol(Depart("AA5679","AMERICAN AIRLINES","07:29","CHARLOTTE","07:00","C81"));
        
  widget.setupUi (this);
  widget.textEditAero->setPlainText (m_aero.reqAeroportFormate ().c_str());
}

/**
 * \brief Crée un nouveau départ à partir de l'interface graphique 
 *        ou génère une exception si le vol entré est déjà présent.
 */
void TableauAeroport::slotAjoutDepart()
{
  AjoutDepart departGUI;
  
  if(departGUI.exec())
    {
      try
        {
          Depart unDepart(departGUI.reqNumero(),departGUI.reqCompagnie(),departGUI.reqHeure (),departGUI.reqVille(),
                      departGUI.reqEmbarq (),departGUI.reqPorte());
          m_aero.ajouterVol(unDepart);
          
        }catch(VolDejaPresentException &exceptPresent)
          {
            QString message = (exceptPresent.what());
            QMessageBox::information(this,"Erreur",message);
          }
      widget.textEditAero->setPlainText(m_aero.reqAeroportFormate ().c_str());
    }
}

/**
 * \brief Crée un nouvel arrivée à partir de l'interface graphique 
 *        ou génère une exception si le vol entré est déjà présent.
 */
void TableauAeroport::slotAjoutArrivee()
{
  AjoutArrivee arriveeGUI;
  
  if(arriveeGUI.exec())
    {
      try
        {
          Arrivee unArrivee(arriveeGUI.reqNumero(),arriveeGUI.reqCompagnie(),arriveeGUI.reqHeure (),arriveeGUI.reqVille(),
                      arriveeGUI.reqStatut ());
          m_aero.ajouterVol(unArrivee);
        }catch(VolDejaPresentException &exceptPresent)
          {
            QString message = (exceptPresent.what());
            QMessageBox::information(this,"Erreur",message);
          }
      widget.textEditAero->setPlainText(m_aero.reqAeroportFormate ().c_str());
    }
}

/**
 * \brief Supprime un vol à partir de l'interface graphique 
 *        ou génère une exception si le vol entré est absent.
 */
void TableauAeroport::slotSupprimerVol()
{
  SupprimerVol SupprimerGUI;
  if(SupprimerGUI.exec())
    {
      try
        {
          m_aero.supprimerVol (SupprimerGUI.reqNumero ());
        }catch(VolAbsentException &exceptAbsent)
          {
            QString message = (exceptAbsent.what());
            QMessageBox::information(this,"Erreur",message);
          }
      widget.textEditAero->setPlainText(m_aero.reqAeroportFormate ().c_str());
    }
}

/**
 * \brief Destructeur de la classe TableauAeroport
 */
TableauAeroport::~TableauAeroport () { }