/**
 * \file main.cpp
 * \brief Interface utilisateur pour la construction de tableaux de départs
 *        et d'arrivées d'un aéroport à partir des informations fournies.
 * \author Rosalie Tremblay
 * \date 26 juin 2024, 13 h 00
 */

#include "Aeroport.h"
#include "validationFormat.h"
#include "Depart.h"
#include "Arrivee.h"
#include <iostream>
#include <string>

using namespace std;
using namespace aerien;

/**
 * \fn int main()
 * \brief Permet la création d'un aéroport par un utilisateur
 */
int main ()
{
  string reponse;
  string codeAero;
  
  do
    {
      cout<<"Quel est le code de l'aéroport dont fait partie le vol? (exemple: ABC)"<<endl;
      cin>>codeAero;
    } while(!util::estCodeValide (codeAero));
  
  Aeroport aeroport(codeAero);
  reponse="1"; //Permet l'affichage de la question une première fois
  
  while(reponse=="1")
    {
      cout<<"Voulez-vous entrer un vol? (Faites 1 pour continuer et 0 pour terminer)"<<endl;
      cin>>reponse;
      
      if (reponse=="1")
        {
          string numVol;
          
          do
            {
              cout<<"Entrez le numero de vol valide (exemple: AB1234) :"<<endl;
              cin>>numVol;
            } while(!util::estNumeroVolValide(numVol));
            
          string Compagnie;  
          
          do
            {
              char buffer[256];
              cout<<"Entrez la compagnie de l'avion (en majuscules):"<<endl;
              cin.ignore(); //Reset le buffer
              cin.getline(buffer,256);
              Compagnie = buffer;
            } while(!util::estNomValide(Compagnie));
          
          char reponse2;
          
          do
            {
              cout<<"Est-ce que le vol est un départ ou un arrivée?\nFaites 'D' pour 'départ' ou 'A' pour 'arrivée'"<<endl;
              cin>>reponse2;
              
              if (reponse2=='D')
                {
                  string heure_decol;
                  
                  do
                    {
                      cout<<"Entrez l'heure de décollage (exemple: 00:59) :\n";
                      cin>>heure_decol;
                    } while (!util::estFormat24HValide (heure_decol));
                    
                  char buffer[256];
                  string ville_dest;
                  
                  do
                    {
                      cout<<"Entrez la ville de destination (en majuscules):\n";
                      cin.ignore();//Reset le buffer
                      cin.getline(buffer,256);
                      ville_dest = buffer;
                    } while(!util::estNomValide (ville_dest));
                    
                  string heure_emb;
                  
                  do
                    {
                      cout<<"Entrez l'heure d'embarquement (exemple: 00:05):\n";
                      cin>>heure_emb;
                    } while(!util::estFormat24HValide (heure_emb));
                    
                  string porte_emb;  
                  
                  do
                    {
                      cout<<"Entrez la porte d'embarquement (exemple: A12):\n";
                      cin>>porte_emb;
                    } while(!util::estPorteValide (porte_emb));
                  
                  aeroport.ajouterVol(Depart(numVol,Compagnie,heure_decol,ville_dest,heure_emb,porte_emb));
                
                }//fin if (reponse2=='D')
              if (reponse2=='A')
                {
                  string heure_atter;
                  
                  do
                    {
                      cout<<"Entrez l'heure d'atterrissage (exemple: 00:59) :\n";
                      cin>>heure_atter;
                    } while (!util::estFormat24HValide (heure_atter));
                    
                  char buffer[256];
                  string ville_prov;
                  
                  do
                    {
                      cout<<"Entrez la ville de provenance (en majuscules):\n";
                      cin.ignore();//Reset le buffer
                      cin.getline(buffer,256);
                      ville_prov = buffer;
                    } while(!util::estNomValide (ville_prov));
                    
                  string statut;
                  
                  do
                    {
                      cout<<"Entrez le statut du vol (Atterri, Retardé ou À l'heure):\n";
                      cin>>statut;
                      
                      if (statut == "Atterri")
                        {
                          statut = util::ajusterLargeur ("Atterri",9);
                        }
                      
                      if (statut == "Retardé")
                        {
                          statut = util::ajusterLargeur ("Retardé",10);
                        }
                  
                    } while(statut!=" Atterri " && statut!=" Retardé " && statut!= "À l'heure");
                    
                  aeroport.ajouterVol(Arrivee(numVol,Compagnie,heure_atter,ville_prov,statut));
                  
                }//fin if (reponse2=='A')
            } while (reponse2 != 'D' && reponse2 != 'A');
        }//fin if (reponse=="1")
      
      if (reponse == "0")
        {
          cout<<"Voici la liste de vols créée pour l'aéroport "<<codeAero<<" :"<<endl;
          cout<<aeroport.reqAeroportFormate();
        }
    }//fin while(reponse=="1")
  
  cout<<"Fin du programme"<<endl;
  return 0;
}//fin int main()