/**
 * \file DepartTesteur.cpp
 * \brief Programme de tests pour la classe Depart
 * \author Rosalie Tremblay
 * \date 23 juin 2024, 13 h 00
 */

#include <gtest/gtest.h>
#include <memory>
#include <vector>

#include "Depart.h"
#include "ContratException.h"

using namespace aerien;
using namespace std;

/**
 * \class DepartTest
 * \brief Fixture  DepartTest pour la création d'objets Depart pour les tests
 */
class DepartTest : public ::testing::Test
{
public:
  DepartTest(): t_depart1("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"),
                t_depart2("DL5064","DELTA","16:05","NEW YORK","15:30","C88"){};
  Depart t_depart1;
  Depart t_depart2;
};

/**
 * \brief Test du Constructeur avec paramètres de Depart
 *        cas valides:
 *         L'heure d'embarquement et le numéro de porte d'embarquement respectent toutes les conditions
 *        cas invalides:
 *         L'heure d'embarquement et le numéro de porte d'embarquement ne respectent pas ses conditions
 */
TEST_F(DepartTest, Constructeur)
{
  ASSERT_EQ("17:15", t_depart1.reqHeureEmbarquement());
  
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","7:15","C86"), ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17H15","C86"), ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","24:15","C86"), ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:60","C86"), ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","18:15","C86"), ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","008:15","C86"), invalid_argument);
  
  ASSERT_EQ("C86", t_depart1.reqPorteEmbarquement());
  
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","7:15","CC86"),ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","7:15","C8"),ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","7:15","CAB"),ContratException);
  ASSERT_THROW(Depart("AC1636","AIR CANADA","18:00","ORLONDO","7:15","886"),ContratException);
}

/**
 * \brief Test de la méthode const std::string& reqHeureEmbarquement()const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(DepartTest, reqHeureEmbarquement)
{
  ASSERT_EQ("17:15", t_depart1.reqHeureEmbarquement());
  ASSERT_EQ("15:30", t_depart2.reqHeureEmbarquement ());
}

/**
 * \brief Test de la méthode const std::string& reqPorteEmbarquement()const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(DepartTest, reqPorteEmbarquement)
{
  ASSERT_EQ("C86", t_depart1.reqPorteEmbarquement ());
  ASSERT_EQ("C88", t_depart2.reqPorteEmbarquement ());
}

/**
 * \brief Test de la méthode void asgHeureEmbarquement (const std::string& p_heureEmbarquement)
 *        cas valide: 
 *         Vérification de l'assignation
 *        cas invalides:
 *         p_heureEmbarquement ne respecte pas ses conditions
 */
TEST_F(DepartTest, asgHeureEmbarquement)
{
  t_depart2.asgHeureEmbarquement("14:08");
  //Après l'assignation
  
  ASSERT_EQ("14:08", t_depart2.reqHeureEmbarquement());
  
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("15H30"),ContratException);
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("5:30"),ContratException);
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("25:30"),ContratException);
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("15:60"),ContratException);
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("16:30"),ContratException);
  ASSERT_THROW(t_depart2.asgHeureEmbarquement ("126:30"),invalid_argument);
}

/**
 * \brief Test de la méthode void asgPorteEmbarquement(const std::string& p_porteEmbarquement)
 *        cas valide: 
 *         Vérification de l'assignation
 *        cas invalide:
 *         p_porteEmbarquement ne respecte pas ses conditions
 */
TEST_F(DepartTest, asgPorteEmbarquement)
{
  t_depart1.asgPorteEmbarquement ("F32");
  //Après l'assignation
  
  ASSERT_EQ("F32", t_depart1.reqPorteEmbarquement());
  
  ASSERT_THROW(t_depart1.asgPorteEmbarquement ("DR76"), ContratException);
  ASSERT_THROW(t_depart1.asgPorteEmbarquement("R7"), ContratException);
  ASSERT_THROW(t_depart1.asgPorteEmbarquement("JRY"),ContratException);
  ASSERT_THROW(t_depart1.asgPorteEmbarquement ("284"),ContratException);
}

/**
 * \brief Test de la méthode virtual std::string reqVolFormate() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(DepartTest, reqVolFormate)
{
  ASSERT_EQ("|AC1636|    AIR CANADA     |18:00|      ORLONDO      |17:15| C86 |\n", t_depart1.reqVolFormate ());
  ASSERT_EQ("|DL5064|       DELTA       |16:05|     NEW YORK      |15:30| C88 |\n", t_depart2.reqVolFormate ());
}

/**
 * \brief Test de la méthode virtual std::unique_ptr<Vol> clone() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(DepartTest, clone)
{
  unique_ptr<Vol> ptr_depart1 = t_depart1.clone();
  ASSERT_EQ(t_depart1.reqVolFormate(),ptr_depart1->reqVolFormate());
  
  unique_ptr<Vol> ptr_depart2 = t_depart2.clone();
  ASSERT_EQ(t_depart2.reqVolFormate(), ptr_depart2->reqVolFormate());
}