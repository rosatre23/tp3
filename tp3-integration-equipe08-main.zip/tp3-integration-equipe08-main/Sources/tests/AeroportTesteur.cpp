/**
 * \file AeroportTesteur.cpp
 * \brief Programme de tests pour la classe Aeroport
 * \author Rosalie Tremblay
 * \date 23 juin 2024, 13 h 00
 */

#include <gtest/gtest.h>

#include "Aeroport.h"
#include "ContratException.h"
#include "VolException.h"

using namespace aerien;
using namespace std;

/**
 * \class AeroportTest
 * \brief Fixture  AeroportTest pour la création d'objets Aeroport pour les tests
 */
class AeroportTest : public ::testing::Test
{
public:
  AeroportTest():t_aeroport1("YQB"),
                 t_aeroport2("LAX"),
                 t_aeroport3("YUL"),
                 t_aeroport4("ABC"){};
  
  Aeroport t_aeroport1;
  Aeroport t_aeroport2;
  Aeroport t_aeroport3;
  Aeroport t_aeroport4;
};

/**
 * \brief Test du Constructeur avec paramètre d'Aeroport
 *        cas valides:
 *         Le code respecte ses conditions
 *        cas invalides:
 *         Le code ne respecte pas ses conditions
 */
TEST_F(AeroportTest, ConstructeurParametre)
{
  ASSERT_EQ("YQB", t_aeroport1.reqCode ());
  
  ASSERT_THROW(Aeroport("EE"),ContratException);
  ASSERT_THROW(Aeroport("EEWJ"),ContratException);
  ASSERT_THROW(Aeroport("yqb"),ContratException);
  ASSERT_THROW(Aeroport("yQB"),ContratException);
  ASSERT_THROW(Aeroport("YqB"),ContratException);
  ASSERT_THROW(Aeroport("YQb"),ContratException);
  ASSERT_THROW(Aeroport("!DH"),ContratException);
}

/**
 * \brief Test du Constructeur par copie avec le code seulement
 *        cas valides:
 *         Le code de l'aéroport existant respecte ses conditions
 *        cas invalides Aucun identifié
 */
TEST_F(AeroportTest, ConstructeurParCopie_Code)
{
  Aeroport aeroport5(t_aeroport1);
  ASSERT_EQ(aeroport5.reqCode (), t_aeroport1.reqCode ());
  
  Aeroport aeroport6(t_aeroport2);
  ASSERT_EQ(aeroport6.reqCode (), t_aeroport2.reqCode ());
}

/**
 * \brief Test du Constructeur par copie avec le code et les vols d'un objet Aeroport déjà existant
 *        cas valides:
 *         Le code de l'aéroport existant respecte ses conditions
 *        cas invalides Aucun identifié
 */
TEST_F(AeroportTest, ConstructeurParCopie_CodeEtVols)
{
  t_aeroport1.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport1.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport1.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans t_aeroport1
  
  Aeroport aeroport5(t_aeroport1);
  //Copie de t_aeroport1 dans aeroport5
  
  ASSERT_EQ(t_aeroport1.reqAeroportFormate (),aeroport5.reqAeroportFormate ());
}

/**
 * \brief Test de l'opérateur Aeroport& operator=(const Aeroport& p_aeroport)
 *        cas valide: 
 *         Vérification de la copie d'un objet Aeroport
 *        cas invalide Aucun d'identifié
 */
TEST_F(AeroportTest, OperateurAssignation)
{
  t_aeroport1.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport1.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport1.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans t_aeroport1
  
  Aeroport aeroport5=t_aeroport1;
  //Assignation des mêmes vols et du même code de t_aeroport1 à aeroport5
  
  ASSERT_EQ(t_aeroport1.reqAeroportFormate (),aeroport5.reqAeroportFormate ());
}

/**
 * \brief Test de la méthode const std::string& reqCode() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(AeroportTest, reqCode)
{
  ASSERT_EQ("YQB",t_aeroport1.reqCode ());
  ASSERT_EQ("LAX",t_aeroport2.reqCode ());
}

/**
 * \brief Test de la méthode void ajouterVol(const Vol& p_vol)
 *        cas valide:
 *         Vérification du retour
 *        cas invalide:
 *         Ajout d'un vol déjà présent
 */
TEST_F(AeroportTest, ajouterVol)
{
  t_aeroport1.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport1.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport1.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans t_aeroport1
  
  Aeroport aeroport7("YQB"); //Construction d'un objet Aeroport
  aeroport7.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  aeroport7.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  aeroport7.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans le nouvel objet aeroport7
  
  ASSERT_EQ(t_aeroport1.reqAeroportFormate (),aeroport7.reqAeroportFormate());
  //Vérification que les mêmes vols ont été ajoutés à 2 aéroports différents
  
  aeroport7.ajouterVol(Arrivee("UA6756","SKYWAY","23:17","QUEBEC"," Atterri "));
  //Ajout d'un vol supplémentaire pour vérifier la copie profonde
  
  ASSERT_NE(t_aeroport1.reqAeroportFormate (),aeroport7.reqAeroportFormate());
  //Vérifie que le vol a été ajouté à aeroport7 sans avoir été ajouté à t_aeroport1
  
  t_aeroport2.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport2.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport2.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans t_aeroport2
  
  ASSERT_NE(t_aeroport1.reqAeroportFormate(),t_aeroport2.reqAeroportFormate());
  //Vérification que, malgré les mêmes vols, les codes font la différence entre les 2 aéroports 
  
  ASSERT_THROW(t_aeroport1.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86")), VolDejaPresentException);
  //Vérification qu'il ne peut y a voir 2 vols avec le même numéro dans un même aéroport
}

/**
 * \brief Test de la méthode void supprimerVol(const std::string& p_numero)
 *        cas valide:
 *         Vérification du retour
 *        cas invalide:
 *         Suppression d'un vol absent
 */
TEST_F(AeroportTest, supprimerVol)
{
  t_aeroport1.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport1.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport1.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  //Ajout des vols dans t_aeroport1
  
  Aeroport t_aeroport8("YQB");//Construction d'un objet Aeroport
  t_aeroport8.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport8.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  //Ajout des vols dans t_aeroport8
  
  t_aeroport1.supprimerVol ("DL5064");
  ASSERT_EQ(t_aeroport8.reqAeroportFormate(),t_aeroport1.reqAeroportFormate());
  //Vérification de la supression du vol
  
  ASSERT_THROW(t_aeroport1.supprimerVol("DL5064"),VolAbsentException);
  //Vérification du lancement de l'exception
}

/**
 * \brief Test de la méthode std::string reqAeroportFormate() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(AeroportTest, reqAeroportFormate)
{
  t_aeroport4.ajouterVol(Depart("AC1636","AIR CANADA","18:00","ORLONDO","17:15","C86"));
  t_aeroport4.ajouterVol(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "));
  t_aeroport4.ajouterVol(Depart("DL5064","DELTA","16:05","NEW YORK","15:30","C88"));
  t_aeroport4.ajouterVol(Depart("AF0345","AIR FRANCE","17:00","PARIS","16:15","E50"));
  t_aeroport4.ajouterVol(Depart("BA0094","BRITISH AIRWAYS","22:15","LONDRES","21:30","A57"));
  t_aeroport4.ajouterVol(Depart("QR0764","QATAR AIRWAYS","21:35","DOHA","21:00","A55"));
  t_aeroport4.ajouterVol(Arrivee("WS0214","WESTJEST","00:34","CALGARY","À l'heure"));
  t_aeroport4.ajouterVol(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH"," Retardé "));
  t_aeroport4.ajouterVol(Depart("TS0820","AIR TRANSAT","06:45","ATLANTA","06:00","C85"));
  t_aeroport4.ajouterVol(Arrivee("AC0424","AIR CANADA","20:41","TORONTO"," Atterri "));
  t_aeroport4.ajouterVol(Depart("WG6544","SUNWING","07:00","CAYO COCO","06:30","A59"));
  t_aeroport4.ajouterVol(Arrivee("UA3647","UNITED AIRLINES","21:06","CHIGAGO","À l'heure"));
  t_aeroport4.ajouterVol(Depart("AA5679","AMERICAN AIRLINES","07:29","CHARLOTTE","07:00","C81"));
  //Ajout des vols dans t_aeroport4
  
  ASSERT_EQ("Aéroport ABC\nTableau des départs\n"
  "------------------------------------------------------------------\n"
  "| VOL  |     COMPAGNIE     |HEURE|        VILLE      |EMBRQ|PORTE|\n"
  "------------------------------------------------------------------\n"
  "|AC1636|    AIR CANADA     |18:00|      ORLONDO      |17:15| C86 |\n"
  "|DL5064|       DELTA       |16:05|     NEW YORK      |15:30| C88 |\n"
  "|AF0345|    AIR FRANCE     |17:00|       PARIS       |16:15| E50 |\n"
  "|BA0094|  BRITISH AIRWAYS  |22:15|      LONDRES      |21:30| A57 |\n"
  "|QR0764|   QATAR AIRWAYS   |21:35|       DOHA        |21:00| A55 |\n"
  "|TS0820|    AIR TRANSAT    |06:45|      ATLANTA      |06:00| C85 |\n"
  "|WG6544|      SUNWING      |07:00|     CAYO COCO     |06:30| A59 |\n"
  "|AA5679| AMERICAN AIRLINES |07:29|     CHARLOTTE     |07:00| C81 |\n"
  "------------------------------------------------------------------\n"
  "Tableau des arrivées\n"
  "----------------------------------------------------------------\n"
  "| VOL  |     COMPAGNIE     |HEURE|       VILLE       |  STATUT |\n"
  "----------------------------------------------------------------\n"
  "|RJ0271|  ROYAL JORDANIAN  |07:12|       AMMAN       | Atterri |\n"
  "|WS0214|     WESTJEST      |00:34|      CALGARY      |À l'heure|\n"
  "|LH0472|     LUFTHANSA     |22:05|      MUNICH       | Retardé |\n"
  "|AC0424|    AIR CANADA     |20:41|      TORONTO      | Atterri |\n"
  "|UA3647|  UNITED AIRLINES  |21:06|      CHIGAGO      |À l'heure|\n"
  "----------------------------------------------------------------\n", 
  t_aeroport4.reqAeroportFormate());
}