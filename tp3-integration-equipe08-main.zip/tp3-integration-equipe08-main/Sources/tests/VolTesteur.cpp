/**
 * \file VolTesteur.cpp
 * \brief Programme de tests pour la classe Vol
 * \author Rosalie Tremblay
 * \date 23 juin 2024, 13 h 00
 */

#include <gtest/gtest.h>

#include "Vol.h"
#include "ContratException.h"

using namespace aerien;
using namespace std;

/**
 * \class VolTest
 * \brief classe de test permettant de tester la classe abstraite Vol
 */
class VolTest : public Vol
{
public:
  VolTest(const std::string& p_numero,const std::string& p_compagnie, 
          const std::string& p_heure, const std::string& p_ville)
          :Vol(p_numero,p_compagnie,p_heure,p_ville){};
          //Instancie un objet Vol
          
  virtual std::unique_ptr<Vol> clone() const {return make_unique <VolTest>(*this);};
  //Doit être implanté car la classe est concrète
};

/**
 * \class UnVol
 * \brief Fixture  UnVol pour la création d'objets Vol pour les tests
 */
class UnVol : public ::testing::Test
{
public:
  UnVol():t_vol1("AC1636","AIR CANADA","18:00","ORLONDO"),
          t_vol2("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"),
          t_vol3("RJ0271","AUTRE","09:23","QUEBEC"){};
  VolTest t_vol1;
  VolTest t_vol2;
  VolTest t_vol3;
};

/**
 * \brief Test du Constructeur avec paramètres de Vol
 *        cas valides:
 *         Le numéro de vol, le nom de la compagnie, l'heure et le nom de la ville respectent toutes les conditions
 *        cas invalides:
 *         Le numéro de vol, le nom de la compagnie, l'heure et/ou le nom de la ville ne respectent pas ses conditions
 */
TEST_F(UnVol, Constructeur)
{
  ASSERT_EQ("AC1636", t_vol1.reqNumero());
  
  ASSERT_THROW( VolTest("AC","AIR CANADA","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("A11636","AIR CANADA","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("1C1636","AIR CANADA","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("111636","AIR CANADA","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("ALBDHS","AIR CANADA","18:00","ORLONDO"),ContratException);
  
  ASSERT_EQ("AIR CANADA", t_vol1.reqCompagnie ());
  
  ASSERT_THROW( VolTest("AC1636","Air Canada","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR@CANADA","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA-","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA ","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AI","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AI ","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AI-","18:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADAAAAAAAAAAA","18:00","ORLONDO"),ContratException);
  
  ASSERT_EQ("18:00",t_vol1.reqHeure ());
  
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18H00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","8:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","24:00","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:60","ORLONDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","018:0","ORLONDO"),invalid_argument);
  
  ASSERT_EQ("ORLONDO", t_vol1.reqVille ());
  
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","Orlondo"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","ORL@NDO"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","ORLONDO-"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","ORLONDO "),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","OR"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","OR "),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","OR-"),ContratException);
  ASSERT_THROW( VolTest("AC1636","AIR CANADA","18:00","ORLONDOOOOOOOOOOOOOO"),ContratException);
} 

/**
 * \brief Test de la méthode const std::string& reqNumero() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol, reqNumero)
{
  ASSERT_EQ("AC1636", t_vol1.reqNumero());
  ASSERT_EQ("RJ0271", t_vol2.reqNumero());
}

/**
 * \brief Test de la méthode const std::string& reqCompagnie() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol, reqCompagnie)
{
  ASSERT_EQ("AIR CANADA", t_vol1.reqCompagnie());
  ASSERT_EQ("ROYAL JORDANIAN", t_vol2.reqCompagnie());
}

/**
 * \brief Test de la méthode const std::string& reqHeure() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol, reqHeure)
{
  ASSERT_EQ("18:00", t_vol1.reqHeure());
  ASSERT_EQ("07:12", t_vol2.reqHeure());
}

/**
 * \brief Test de la méthode const std::string& reqVille() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol, reqVille)
{
  ASSERT_EQ("ORLONDO", t_vol1.reqVille());
  ASSERT_EQ("AMMAN", t_vol2.reqVille());
}

/**
 * \brief Test de la méthode void asgHeure(const std::string& p_heure)
 *        cas valide: 
 *         Vérification de l'assignation
 *        cas invalides:
 *         p_heure ne respecte pas ses conditions
 */
TEST_F(UnVol, asgHeure)
{
  t_vol2.asgHeure("08:00");
  //Après l'assignation
  
  ASSERT_EQ("08:00", t_vol2.reqHeure ());
  
  ASSERT_THROW(t_vol2.asgHeure("8:00"),ContratException);
  ASSERT_THROW(t_vol2.asgHeure("08H00"),ContratException);
  ASSERT_THROW(t_vol2.asgHeure("24:00"),ContratException);
  ASSERT_THROW(t_vol2.asgHeure("18:60"),ContratException);
  ASSERT_THROW(t_vol2.asgHeure("218:3"),invalid_argument);
}

/**
 * \brief Test de l'opérateur bool operator==(const Vol& p_vol)
 *        cas valide: 
 *         Vérification de l'égalité des numéros de vols
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol,OperateurEgalite)
{
  EXPECT_TRUE(t_vol2==t_vol3);
  EXPECT_FALSE(t_vol1==t_vol2);
  EXPECT_FALSE(t_vol1==t_vol3);
}

/**
 * \brief Test de la méthode virtual std::string reqVolFormate() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(UnVol, reqVolFormate)
{
  ASSERT_EQ("|AC1636|    AIR CANADA     |18:00|      ORLONDO      |", t_vol1.reqVolFormate ());
  ASSERT_EQ("|RJ0271|  ROYAL JORDANIAN  |07:12|       AMMAN       |",t_vol2.reqVolFormate ());
}