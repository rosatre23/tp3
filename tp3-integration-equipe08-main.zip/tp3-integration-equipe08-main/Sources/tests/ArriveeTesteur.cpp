/**
 * \file ArriveeTesteur.cpp
 * \brief Programme de tests pour la classe Arrivee
 * \author Rosalie Tremblay
 * \date 23 juin 2024, 13 h 00
 */

#include <gtest/gtest.h>

#include "Arrivee.h"
#include "ContratException.h"

using namespace aerien;
using namespace std;

/**
 * \class ArriveeTest
 * \brief Fixture  ArriveeTest pour la création d'objets Arrivee pour les tests
 */
class ArriveeTest : public ::testing::Test
{
public:
  ArriveeTest(): t_arrivee1("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri "),
                 t_arrivee2("WS0214","WESTJEST","00:34","CALGARY","À l'heure"),
                 t_arrivee3("LH0472","LUFTHANSA","22:05","MUNICH"," Retardé "){};
  
  Arrivee t_arrivee1;
  Arrivee t_arrivee2;
  Arrivee t_arrivee3;
};

/**
 * \brief Test du Constructeur avec paramètres d'Arrivee
 *        cas valides:
 *         Le statut respecte ses conditions
 *        cas invalides:
 *         Le statut ne respecte pas ses conditions
 */
TEST_F(ArriveeTest, Constructeur)
{
  ASSERT_EQ(" Atterri ", t_arrivee1.reqStatut ());
  ASSERT_EQ("À l'heure", t_arrivee2.reqStatut());
  ASSERT_EQ(" Retardé ", t_arrivee3.reqStatut ());
  
  ASSERT_THROW(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN","Atterri"),ContratException);
  ASSERT_THROW(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN"," Atterri"),ContratException);
  ASSERT_THROW(Arrivee("RJ0271","ROYAL JORDANIAN","07:12","AMMAN","Atterri "),ContratException);
  
  ASSERT_THROW(Arrivee("WS0214","WESTJEST","00:34","CALGARY","Àl'heure"),ContratException);
  ASSERT_THROW(Arrivee("WS0214","WESTJEST","00:34","CALGARY","À l’heure"),ContratException);
  ASSERT_THROW(Arrivee("WS0214","WESTJEST","00:34","CALGARY","A l'heure"),ContratException);
  ASSERT_THROW(Arrivee("WS0214","WESTJEST","00:34","CALGARY","à l'heure"),ContratException);

  ASSERT_THROW(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH","Retardé "),ContratException);
  ASSERT_THROW(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH"," Retardé"),ContratException);
  ASSERT_THROW(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH","Retardé"),ContratException);
  ASSERT_THROW(Arrivee("LH0472","LUFTHANSA","22:05","MUNICH"," Retarde "),ContratException);
}

/**
 * \brief Test de la méthode const std::string& reqStatut() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(ArriveeTest, reqStatut)
{
  ASSERT_EQ(" Atterri ", t_arrivee1.reqStatut ());
  ASSERT_EQ("À l'heure", t_arrivee2.reqStatut());
  ASSERT_EQ(" Retardé ", t_arrivee3.reqStatut ());
}

/**
 * \brief Test de la méthode void asgStatut(const std::string& p_statut)
 *        cas valide: 
 *         Vérification de l'assignation
 *        cas invalides:
 *         p_statut ne respecte pas ses conditions
 */
TEST_F(ArriveeTest, asgStatut)
{
  t_arrivee1.asgStatut (" Retardé ");
  //Après l'assignation
  
  ASSERT_EQ(" Retardé ", t_arrivee1.reqStatut ());
  
  t_arrivee1.asgStatut ("À l'heure");
  //Après l'assignation
  
  ASSERT_EQ("À l'heure", t_arrivee1.reqStatut ());
  
  t_arrivee1.asgStatut (" Atterri ");
  //Après l'assignation
  
  ASSERT_EQ(" Atterri ", t_arrivee1.reqStatut ());
  
  ASSERT_THROW(t_arrivee1.asgStatut ("À l’heure"), ContratException);
  ASSERT_THROW(t_arrivee1.asgStatut("Atterri"), ContratException);
  ASSERT_THROW(t_arrivee1.asgStatut("Retardé"), ContratException);
}

/**
 * \brief Test de la méthode virtual std::string reqVolFormate() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(ArriveeTest, reqVolFormate)
{
  ASSERT_EQ("|RJ0271|  ROYAL JORDANIAN  |07:12|       AMMAN       | Atterri |\n", t_arrivee1.reqVolFormate());
  ASSERT_EQ("|WS0214|     WESTJEST      |00:34|      CALGARY      |À l'heure|\n", t_arrivee2.reqVolFormate());
  ASSERT_EQ("|LH0472|     LUFTHANSA     |22:05|      MUNICH       | Retardé |\n", t_arrivee3.reqVolFormate ());
}

/**
 * \brief Test de la méthode virtual std::unique_ptr<Vol> clone() const
 *        cas valide:
 *         Vérification du retour
 *        cas invalide Aucun d'identifié
 */
TEST_F(ArriveeTest, clone)
{
  unique_ptr<Vol> ptr_arrivee1 = t_arrivee1.clone();
  ASSERT_EQ(t_arrivee1.reqVolFormate (),ptr_arrivee1->reqVolFormate() );
  
  unique_ptr<Vol> ptr_arrivee2 = t_arrivee2.clone();
  ASSERT_EQ(t_arrivee2.reqVolFormate(), ptr_arrivee2->reqVolFormate());
}