/**
 * \file Aeroport.cpp
 * \brief Implantation de la classe Aeroport
 * \author Rosalie Tremblay
 * \date 26 juin 2024, 13 h 00
 */

#include <sstream>

#include "Aeroport.h"
#include "validationFormat.h"
#include "ContratException.h"
#include "VolException.h"

using namespace std;

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Aeroport
 */
namespace aerien
{
  
/**
 * \brief Constructeur avec paramètres
 *        Un objet Aeroport est construit à partir d'une valeur passée en paramètre.
 *        L'objet est construit si le paramètre est valide sinon une exception est générée.
 * \param[in] p_code      Code de l'aéroport
 * \pre p_code doit être dans un format valide
 * \post L'objet est bien construit, l'attribut est initialisé avec la valeur du paramètre
 */
Aeroport::Aeroport (const std::string& p_code):m_code(p_code) 
{
  PRECONDITION(util::estCodeValide (p_code));
  //Vérification de la validité des paramètres
  
  POSTCONDITION(m_code==p_code);
  
  INVARIANTS();
}

/**
 * \brief Constructeur par copie 
 *        Un objet Aeroport est construit à partir d'un autre objet Aeroport déjà existant.
 *        L'objet est construit si le code de l'aéroport est valide sinon une exception est générée.
 * \param[in] p_aeroport      Nom de l'aéroport déjà existant
 * \pre m_code de l'aéroport doit être dans un format valide
 * \post L'objet est bien construit, l'attribut est initialisé avec la valeur de l'attribut de l'objet existant
 */
Aeroport::Aeroport (const Aeroport& p_aeroport):m_code(p_aeroport.m_code) 
{
  PRECONDITION(util::estCodeValide(p_aeroport.m_code));
  
  for (const auto & element : p_aeroport.m_vols)
    {
      ajouterVol(*element); //copie en profondeur de tous les vols
    }
  
  POSTCONDITION(m_code == p_aeroport.m_code);
  
  INVARIANTS();
}

/**
 * \brief Opérateur d'assignation
 * \param[in] p_vol Un objet Aeroport
 * \pre m_code de l'aéroport existant doit être dans un format valide
 * \return Un objet Aeroport contenant les mêmes vols que l'objet existant
 */
Aeroport& Aeroport::operator=(const Aeroport& p_aeroport)
{
  PRECONDITION(util::estCodeValide(p_aeroport.m_code));
  
  for (const auto & element : p_aeroport.m_vols)
    {
      ajouterVol(*element); //copie en profondeur de tous les vols
    }
  INVARIANTS();
  
  return *this;
}

/**
 * \brief Accesseur pour le code de l'aéroport
 * \return Une chaine de caractères correspondant au code 
 */
const std::string& Aeroport::reqCode() const
{
  return m_code;
}

/**
 * \brief Ajoute un vecteur Vol à la fin d'un tableau de vols.
 *        Si un vol contenant le même numéro de vol est déjà présent, une exception est générée.
 * \param[in] p_vol     Un vecteur Vol
 */
void Aeroport::ajouterVol(const Vol& p_vol)
{
  bool present = false;
  
  auto iter = m_vols.begin (); //Iterateur associé à un vecteur de pointeurs uniques vers des objets Vol
  
  while (iter<m_vols.end() )
    {
      if(**iter==p_vol) //double déréférencement
        {
          present = true;
          break;
        }
      iter++;
    }
  if(present)
    {
      throw VolDejaPresentException("Ce vol existe:\n" + p_vol.reqVolFormate ());
    }
  else
    {
      m_vols.push_back(p_vol.clone()); //Liste de pointeurs vers des vols
    }
  
  INVARIANTS();
}

/**
 * \brief Supprime un objet Vol du tableau de vols.
 *        Si aucun vol ne contenant le numéro de vol à supprimer, une exception est générée.
 * \param[in] p_numero      Numero du vol
 * \pre Le numero de vol doit être dans un format valide
 */
void Aeroport::supprimerVol (const std::string& p_numero)
{
  PRECONDITION(util::estNumeroVolValide (p_numero));
  
  bool absent=true;
  
  auto iter=m_vols.begin();
  
  while (iter<m_vols.end())
    {
      if((iter->get())->reqNumero()==p_numero)
        {
          absent=false;
          break;
        }
      iter++;
    }
  
  if(absent)
    {
      throw VolAbsentException("Ce vol n'existe pas:\n" + p_numero);
    }
  else
    {
      m_vols.erase(iter);
    }
          
  INVARIANTS();
}

/**
 * \brief Méthode pour l'affichage des tableaux d'un objet Aeroport
 * \return Une chaine de caractères qui prend la forme de tableaux de 
 *         départs et d'arrivées pour un objet Aeroport.
 */
string Aeroport::reqAeroportFormate() const
{
  string resultat;
  ostringstream os1;
  ostringstream os2;
  
  os1<<"Aéroport "<<m_code<<endl;
  
  //Préparation des tableaux
  os1<<"Tableau des départs\n";
  os1<<"------------------------------------------------------------------\n";
  os1<<"| VOL  |     COMPAGNIE     |HEURE|        VILLE      |EMBRQ|PORTE|\n";
  os1<<"------------------------------------------------------------------\n";
  
  for (size_t i=0; i<m_vols.size(); i++)
    {
      ostringstream vols;
      vols<<m_vols[i]->reqVolFormate();
      
      if (vols.str().length() == 67) //Placements des départ dans os1
        {
          os1 << m_vols[i]->reqVolFormate();
        }
      if (vols.str().length() == 65 || vols.str().length() == 66) //Placements des arrivées dans os2
        {
          os2<<m_vols[i]->reqVolFormate();
        }
      vols.clear(); //Reset le calcul des nombres de caractères des vols à 0 
    }
  
  //Tableau des départs terminé
  os1<<"------------------------------------------------------------------\n";
  os1<<"Tableau des arrivées\n"; //Commencement du tableau des arrivées
  os1<<"----------------------------------------------------------------\n";
  os1<<"| VOL  |     COMPAGNIE     |HEURE|       VILLE       |  STATUT |\n";
  os1<<"----------------------------------------------------------------\n";
  
  //Les arrivées ont déjà été placés dans os2 lors du passage dans la boucle
  //Dernière ligne du tableau des arrivées
  os2<<"----------------------------------------------------------------\n";
  
  return resultat = os1.str() + os2.str();
} 

/**
 * \brief Assure le respect des conditions des paramètres
 */
void Aeroport::verifieInvariant() const
{
  INVARIANT(util::estCodeValide (m_code));
}

}// namespace aerien