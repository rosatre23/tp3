/**
 * \file VolException.h
 * \brief Fichier contenant la déclaration de la classe VolException
 * \author Rosalie Tremblay
 * \date 10 juillet 2024, 16 h 00
 */

/**
 *\namespace aerien
 * Contient les exceptions qui peuvent être appelées par des objets Aeroport
 */
namespace aerien
{

#ifndef VOLEXCEPTION_H
#define VOLEXCEPTION_H
  
/**
 * \class VolException
 * \brief Classe pour la gestion des erreurs de Vol.
 */
class VolException : public std::runtime_error
{
public:
  VolException (const std::string& p_raison): std::runtime_error(p_raison){};
};

/**
 * \class VolDejaPresentException
 * \brief Classe pour la gestion des erreurs de Vols déjà présents
 */
class VolDejaPresentException : public VolException
{
public:
  VolDejaPresentException(const std::string& p_raison):VolException(p_raison){};
};

/**
 * \class VolAbsentException
 * \brief Classe pour la gestion des erreurs de Vols absents
 */
class VolAbsentException : public VolException
{
public:
  VolAbsentException(const std::string& p_raison):VolException(p_raison){};
};

#endif /* VOLEXCEPTION_H */

} //namespace aerien