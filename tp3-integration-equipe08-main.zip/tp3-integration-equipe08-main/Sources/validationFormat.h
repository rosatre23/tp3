/**
 * \file validationFormat.h
 * \brief déclarations des fonctions de validation TP1 Aerien
 * \author Mohamed Haj Taieb
 * \date 2024-05-04
 */

#include <string>

/**
 *\namespace util
 * Contient les fonctions qui peuvent être utilisées pour valider le 
 * respect des conditions de différents paramètres
 */
namespace util
{
#ifndef VALIDATIONFORMAT_H
#define VALIDATIONFORMAT_H

/**
 * \class validationFormat
 * \brief Classe validationFormat permettant de valider le 
 *        respect des conditions de différents paramètres
 */
bool estNumeroVolValide(const std::string& p_numeroVol);

bool estFormat24HValide(const std::string& p_heure);

bool estPorteValide(const std::string& p_porte);

bool estNomValide(const std::string& p_nom);

void traiterFichierVols (std::istream& p_flux);

bool estCodeValide(const std::string& p_code);

std::string  ajusterLargeur(const std::string& p_champ, int p_largeur=19);

#endif /* VALIDATIONFORMAT_H */

}//namespace util
