/**
 * \file Arrivee.h
 * \brief Fichier contenant la déclaration de la classe Arrivee, héritier de la classe Vol
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include "Vol.h"

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Arrivee
 */
namespace aerien
{
  
#ifndef ARRIVEE_H
#define ARRIVEE_H

/**
 * \class Arrivee
 * \brief Classe Arrivee permettant de modéliser les objets Arrivee, qui sont aussi des objets Vol
 */
class Arrivee: public Vol
{
public:
  Arrivee (const std::string& p_numero,const std::string& p_compagnie, 
           const std::string& p_heure, const std::string& p_ville, 
           const std::string& p_statut);
  
  const std::string& reqStatut() const;
  
  void asgStatut(const std::string& p_statut);
  
  virtual std::string reqVolFormate() const;
  
  virtual std::unique_ptr<Vol> clone ()const;
  
private:
  std::string m_statut;
  
  void verifieInvariant() const;
};

#endif /* ARRIVEE_H */

}//namespace aerien