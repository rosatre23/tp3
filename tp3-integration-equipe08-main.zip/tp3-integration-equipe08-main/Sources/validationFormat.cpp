/**
 * \file validationFormat.cpp
 * \brief définition des fonctions de validation TP1 Aerien
 * \author Mohamed Haj Taieb
 * \date 2024-05-04
 */

#include "validationFormat.h"

using namespace std;

/**
 *\namespace util
 * Contient les fonctions qui peuvent être utilisées pour valider le 
 * respect des conditions de différents paramètres
 */
namespace util
{

/**
 * \brief Méthode de vérification de la validité d'un numéro de vol
 * \param[in] p_numeroVol   Numéro de vol
 * \return Un booléen qui informe si le numéro est valide ou non
 */
bool estNumeroVolValide(const std::string& p_numeroVol)
{
  bool numValide = (p_numeroVol.length()==6); 
  numValide &= isupper(p_numeroVol[0]) && isupper(p_numeroVol[1]) ;
  for (int i = 2; i <6; i++)
    {
        numValide&=isdigit(p_numeroVol[i]) ;
    }
  return numValide;
}

/**
 * \brief Méthode de vérification de la validité d'une heure
 * \param[in] p_heure   Heure à vérifier
 * \return Un booléen qui informe si l'heure est valide ou non
 */
bool estFormat24HValide(const std::string& p_heure)
{
  bool heureValide = (p_heure.length()==5 && p_heure[2]==':'); 
  heureValide &= isdigit(p_heure[0]) && isdigit(p_heure[1]) ;
  heureValide &= isdigit(p_heure[3]) && isdigit(p_heure[4]) ;
  heureValide &= stoi(p_heure.substr(0,2))<24; 
  heureValide &= stoi(p_heure.substr(3,2))<60; 

  return heureValide;
}

/**
 * \brief Méthode de vérification du numéro de porte d'embarquement d'un vol
 * \param[in] p_porte   Numéro de porte d'embarquement d'un vol
 * \return Un booléen qui informe si le numéro de porte d'embarquement est valide ou non
 */
bool estPorteValide(const std::string& p_porte)
{
  bool porteValide = (p_porte.length()==3); 
  porteValide &= isupper(p_porte[0]) && true ;
  porteValide&=isdigit(p_porte[1]) ;
  porteValide&=isdigit(p_porte[2]) ;
  porteValide&=!(p_porte[1]=='0'&&p_porte[2]=='0');
  
  return porteValide;
}

/**
 * \brief Méthode de vérification d'un nom
 * \param[in] p_nom     Nom d'une compagnie ou d'une ville
 * \return Un booléen qui informe si le nom est valide ou non
 */
bool estNomValide (const string& p_nom)
{
  int longNom= p_nom.length();
  if(longNom<3 || longNom>19 || !isupper(p_nom[0]))
    return false;

  for (int i = 1; i < p_nom.length (); i++)
    {
      if (!isalpha (p_nom[i]))
        {
          if (p_nom[i] == '-' || p_nom[i] == ' ' )
            {
              if (i == p_nom.length () - 1 || p_nom[i + 1] == '-' ||  p_nom[i + 1] == ' ' || !isupper(p_nom[i+1]))
                return false;
              i++;
            }
          else
            return false;
        }
      else if(!isupper(p_nom[i]))//else if(!islower(p_nom[i]))
        return false;
    }
  return true;
}


/**
 * \brief Ajuste la largeur du champs en ajoutant des espaces des 2 cotés
 * \param[in] string le champ à ajuster
 * \param[in] int la largeur du champ souhaitée
 * \return string ajusté
 */   
string  ajusterLargeur(const string& p_champ, int p_largeur)
{
  string champAjuste = p_champ;
  bool ajoutEspaceAGauche=false;
    while (champAjuste.size()<(u_int)p_largeur)
      {
        if (ajoutEspaceAGauche)
            champAjuste = " " + champAjuste;
        else
            champAjuste = champAjuste + " ";

        ajoutEspaceAGauche=!ajoutEspaceAGauche;
      }         
  return champAjuste;
}

/**
 * \brief Méthode de vérification du code d'un aéroport
 * \param[in] p_code    Code d'un aéroport
 * \return Un booléen qui informe si le code est valide ou non
 */
bool estCodeValide(const std::string& p_code)
{
  if (p_code.length()!=3)
    return false;
  for (int i = 0; i<3; i++)
    if(!isupper(p_code[i]))
      return false;
  return true;
}

}//namespace util