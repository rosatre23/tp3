/**
 * \file Aeroport.h
 * \brief Fichier contenant la déclaration de la classe Aeroport
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include <memory>
#include <vector>

#include "Vol.h"
#include "Depart.h"
#include "Arrivee.h"

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Aeroport
 */
namespace aerien
{
  
#ifndef AEROPORT_H
#define AEROPORT_H

/**
 * \class Aeroport
 * \brief Classe Aeroport permettant de modéliser les objets Aeroport
 */
class Aeroport
{
public:
  Aeroport (const std::string& p_code);
  Aeroport (const Aeroport& p_aeroport);
  
  Aeroport& operator=(const Aeroport& p_aeroport);
  
  const std::string& reqCode() const;
  
  void ajouterVol(const Vol& p_vol); 
  
  void supprimerVol (const std::string& p_numero);
  
  std::string reqAeroportFormate() const; 
  
private:
  std::string m_code;
  std::vector<std::unique_ptr<Vol>> m_vols; 
  
  void verifieInvariant() const;
};

#endif /* AEROPORT_H */

}//namespace aerien