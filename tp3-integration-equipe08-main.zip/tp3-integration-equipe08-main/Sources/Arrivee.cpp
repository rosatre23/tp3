/**
 * \file Arrivee.cpp
 * \brief Implantation de la classe Arrivee
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */
#include <sstream>

#include "ContratException.h"
#include "Arrivee.h"

using namespace std;

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Arrivee
 */
namespace aerien
{
  
/**
 * \brief Constructeur avec paramètres
 *        Un objet Arrivee est construit à partir des valeurs passées en paramètres.
 *        L'objet est construit si les paramètres sont valides sinon une exception est générée.
 * \param[in] p_numero      Numéro de vol
 * \param[in] p_compagnie   La compagnie de l'avion
 * \param[in] p_heure       L'heure de décollage ou d'atterrissage
 * \param[in] p_ville       La ville de destination ou de provenance
 * \param[in] p_statut      Statut du vol
 * \pre p_statut doit être dans un format valide
 * \post L'objet est bien construit, les attributs sont initialisés avec les valeurs des paramètres
 */
Arrivee::Arrivee (const std::string& p_numero,
                  const std::string& p_compagnie,
                  const std::string& p_heure, 
                  const std::string& p_ville, 
                  const std::string& p_statut): 
                  Vol(p_numero, p_compagnie, p_heure, p_ville), 
                  m_statut(p_statut) 
{
  PRECONDITION(p_statut==" Atterri " || p_statut == " Retardé " || p_statut == "À l'heure");
  //Vérification de la validité des paramètres
  
  POSTCONDITION(m_statut == p_statut);
  
  INVARIANTS();
}

/**
 * \brief Accesseur pour le statut de l'arrivée
 * \return Une chaine de caractères correspondant au statut 
 */
const std::string& Arrivee::reqStatut() const
{
  return m_statut;
}

/**
 * \brief Mutateur pour le statut de l'arrivée
 * \param[in] p_statut Nouveau statut
 * \pre p_statut doit être dans un format valide
 * \post Le nouveau statut est bien assigné à l'objet
 */
void Arrivee::asgStatut(const std::string& p_statut)
{
  PRECONDITION(p_statut==" Atterri " || p_statut == " Retardé " || p_statut == "À l'heure");
  
  m_statut = p_statut;
  
  POSTCONDITION(m_statut == p_statut);
  
  INVARIANTS();
}

/**
 * \brief Méthode pour l'affichage d'un arrivée
 * \return Une chaine de caractères qui contient les informations de l'arrivée 
 */
std::string Arrivee::reqVolFormate() const
{
  ostringstream os;
  os<<Vol::reqVolFormate();
  os<<m_statut<<"|"<<endl;
  return os.str();
}

/**
 * \brief Fait une copie en profondeur d'un vecteur Arrivee
 * \return Un pointeur unique vers un vecteur Vol
 */
std::unique_ptr<Vol> Arrivee::clone ()const
{
  return make_unique <Arrivee> (*this);
}

/**
 * \brief Assure le respect des conditions des paramètres
 */
void Arrivee::verifieInvariant() const
{
  INVARIANT(m_statut==" Atterri " || m_statut == " Retardé " || m_statut == "À l'heure");
}

}//namespace aerien