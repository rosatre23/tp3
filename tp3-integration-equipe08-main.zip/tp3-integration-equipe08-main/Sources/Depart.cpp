/**
 * \file Depart.cpp
 * \brief Implantation de la classe Depart
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include <sstream>

#include "Depart.h"
#include "validationFormat.h"
#include "ContratException.h"

using namespace std;

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Depart
 */
namespace aerien
{
  
/**
 * \brief Constructeur avec paramètres
 *        Un objet Depart est construit à partir des valeurs passées en paramètres.
 *        L'objet est construit si les paramètres sont valides sinon une exception est générée.
 * \param[in] p_numero              Numéro de vol
 * \param[in] p_compagnie           La compagnie de l'avion
 * \param[in] p_heure               L'heure de décollage ou d'atterrissage
 * \param[in] p_ville               La ville de destination ou de provenance
 * \param[in] p_porteEmbarquement   Numéro de la porte d'embarquement
 * \param[in] p_heureEmbarquement   L'heure d'embarquement des passagers
 * \pre p_porteEmbarquement, p_heureEmbarquement doivent être dans un format valide
 * \post L'objet est bien construit, les attributs sont initialisés avec les valeurs des paramètres
 */
Depart::Depart (const std::string& p_numero,
                const std::string& p_compagnie, 
                const std::string& p_heure, 
                const std::string& p_ville, 
                const std::string& p_heureEmbarquement, 
                const std::string& p_porteEmbarquement): 
                Vol(p_numero, p_compagnie, p_heure, p_ville), 
                m_porteEmbarquement(p_porteEmbarquement), 
                m_heureEmbarquement(p_heureEmbarquement)
{
PRECONDITION(util::estPorteValide (p_porteEmbarquement));
PRECONDITION((util::estFormat24HValide (p_heureEmbarquement)) && (p_heureEmbarquement< Vol::reqHeure ()));
//Vérification de la validité des paramètres

POSTCONDITION(m_porteEmbarquement == p_porteEmbarquement);
POSTCONDITION(m_heureEmbarquement == p_heureEmbarquement);

INVARIANTS();
}
  
/**
 * \brief Accesseur pour la porte d'embarquement
 * \return Une chaine de caractères correspondant à la porte d'embarquement 
 */
const std::string& Depart::reqPorteEmbarquement()const
{
  return m_porteEmbarquement;
}

/**
 * \brief Accesseur pour l'heure d'embarquement
 * \return Une chaine de caractères correspondant à l'heure d'embarquement 
 */
const std::string& Depart::reqHeureEmbarquement()const
{
  return m_heureEmbarquement;
}

/**
 * \brief Mutateur pour la porte d'embarquement
 * \param[in] p_heure Nouveau numéro de porte
 * \pre p_porteEmbarquement doit être dans un format valide
 * \post La nouvelle porte est bien assignée à l'objet
 */
void Depart::asgPorteEmbarquement(const std::string& p_porteEmbarquement)
{
  PRECONDITION(util::estPorteValide (p_porteEmbarquement));
  
  m_porteEmbarquement = p_porteEmbarquement;
  
  POSTCONDITION(m_porteEmbarquement == p_porteEmbarquement);
  
  INVARIANTS();
}

/**
 * \brief Mutateur pour l'heure d'embarquement
 * \param[in] p_heureEmbarqement Nouvelle heure d'embarquement
 * \pre p_heureEmbarquement doit être dans un format valide
 * \post La nouvelle heure d'embarquement est bien assignée à l'objet
 */
void Depart::asgHeureEmbarquement (const std::string& p_heureEmbarquement)
{
  PRECONDITION((util::estFormat24HValide(p_heureEmbarquement)) && (p_heureEmbarquement < Vol::reqHeure ()));
  
  m_heureEmbarquement = p_heureEmbarquement;
  
  POSTCONDITION(m_heureEmbarquement == p_heureEmbarquement);
  
  INVARIANTS();
}

/**
 * \brief Méthode pour l'affichage d'un départ
 * \return Une chaine de caractères qui contient les informations du départ 
 */
string Depart::reqVolFormate() const
{
  ostringstream os;
  os<<Vol::reqVolFormate();
  os<<m_heureEmbarquement<<"|"<<util::ajusterLargeur(m_porteEmbarquement,5)<<"|"<<endl;
  return os.str();
}

/**
 * \brief Fait une copie en profondeur d'un vecteur Depart
 * \return Un pointeur unique vers un vecteur Vol
 */
std::unique_ptr<Vol> Depart::clone() const
{
  return make_unique <Depart> (*this);
}

/**
 * \brief Assure le respect des conditions des paramètres
 */
void Depart::verifieInvariant () const
{
  INVARIANT(util::estPorteValide (m_porteEmbarquement));
  INVARIANT((util::estFormat24HValide (m_heureEmbarquement)) && (m_heureEmbarquement< Vol::reqHeure ()));
}

}//namespace aerien