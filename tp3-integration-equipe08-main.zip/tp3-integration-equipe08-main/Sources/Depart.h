/**
 * \file Depart.h
 * \brief Fichier contenant la déclaration de la classe Depart, héritier de la classe Vol
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include "Vol.h"

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Depart
 */
namespace aerien
{
  
#ifndef DEPART_H
#define DEPART_H

/**
 * \class Depart
 * \brief Classe Depart permettant de modéliser les objets Depart, qui sont aussi des objets Vol
 */
class Depart : public aerien::Vol
{
public:
  Depart (const std::string& p_numero,const std::string& p_compagnie, 
          const std::string& p_heure, const std::string& p_ville, 
          const std::string& p_heureEmbarquement, const std::string& p_porteEmbarquement);
  
  const std::string& reqPorteEmbarquement()const;
  const std::string& reqHeureEmbarquement()const;
  
  void asgPorteEmbarquement(const std::string& p_porteEmbarquement);
  void asgHeureEmbarquement (const std::string& p_heureEmbarquement);
  
  virtual std::string reqVolFormate() const;
  
  virtual std::unique_ptr<Vol> clone() const;
  
private:
  std::string m_porteEmbarquement;
  std::string m_heureEmbarquement;
  
  void verifieInvariant () const;
};

#endif /* DEPART_H */

}//namespace aerien