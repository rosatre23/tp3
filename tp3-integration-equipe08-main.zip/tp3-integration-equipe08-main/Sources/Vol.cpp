/**
 * \file Vol.cpp
 * \brief Implantation de la classe Vol
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include <sstream>
#include <memory>

#include "ContratException.h"
#include "validationFormat.h"
#include "Vol.h"

using namespace std;

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Vol
 */
namespace aerien
{
  
/**
 * \brief Constructeur avec paramètres
 *        Un objet Vol est construit à partir des valeurs passées en paramètres.
 *        L'objet est construit si les paramètres sont valides sinon une exception est générée.
 * \param[in] p_numero      Numéro de vol
 * \param[in] p_compagnie   La compagnie de l'avion
 * \param[in] p_heure       L'heure de décollage ou d'atterrissage
 * \param[in] p_ville       La ville de destination ou de provenance
 * \pre p_numero, p_compagnie, p_heure, p_ville doivent être dans un format valide
 * \post L'objet est bien construit, les attributs sont initialisés avec les valeurs des paramètres
 */
Vol::Vol (const std::string& p_numero,
          const std::string& p_compagnie, 
          const std::string& p_heure, 
          const std::string& p_ville)
          :m_numero(p_numero), m_compagnie(p_compagnie), 
          m_heure(p_heure), m_ville(p_ville)
{
PRECONDITION(util::estNumeroVolValide(p_numero));
PRECONDITION(util::estNomValide(p_compagnie));
PRECONDITION(util::estFormat24HValide(p_heure));
PRECONDITION(util::estNomValide(p_ville));
//Vérification de la validité des paramètres

POSTCONDITION(m_numero==p_numero);
POSTCONDITION(m_compagnie==p_compagnie);
POSTCONDITION(m_heure==p_heure);
POSTCONDITION(m_ville==p_ville);

INVARIANTS();
}

/**
 * \brief Accesseur pour le numéro de vol
 * \return Une chaine de caractères correspondant au numéro de vol 
 */
const std::string& Vol::reqNumero() const
{
  return m_numero;
}

/**
 * \brief Accesseur pour la compagnie
 * \return Une chaine de caractères correspondant à la compagnie 
 */
const std::string& Vol::reqCompagnie() const
{
  return m_compagnie;
}

/**
 * \brief Accesseur pour l'heure de décollage ou d'atterrissage
 * \return Une chaine de caractères correspondant à l'heure
 */
const std::string& Vol::reqHeure() const
{
  return m_heure;
}

/**
 * \brief Accesseur pour la ville de destination ou de provenance
 * \return Une chaine de caractères correspondant à la ville 
 */
const std::string& Vol::reqVille() const
{
  return m_ville;
}

/**
 * \brief Mutateur pour l'heure de décollage ou d'atterrissage
 * \param[in] p_heure Nouvelle heure
 * \pre p_heure doit être dans un format valide
 * \post La nouvelle heure est bien assignée à l'objet
 */
void Vol::asgHeure(const std::string& p_heure)
{
  PRECONDITION(util::estFormat24HValide(p_heure));
  
  m_heure = p_heure;
  
  POSTCONDITION(m_heure==p_heure);
  
  INVARIANTS();
}

/**
 * \brief Opérateur de comparaison d'égalité entre les numéros de vol de deux vols
 * \param[in] p_vol Un objet Vol
 * \return Une valeur booléenne 
 */
bool Vol::operator==(const Vol& p_vol)
{
  INVARIANTS();
  return m_numero== p_vol.m_numero;
}

/**
 * \brief Méthode pour l'affichage d'un vol
 * \return Une chaine de caractères qui contient les informations du vol 
 */
string Vol::reqVolFormate() const
{
  ostringstream oss;
  oss<<"|"<<m_numero<<"|"<<util::ajusterLargeur(m_compagnie);
  oss<<"|"<<m_heure<<"|"<<util::ajusterLargeur(m_ville)<<"|";
  return oss.str();
}

/**
 * \brief Assure le respect des conditions des paramètres
 */
void Vol::verifieInvariant() const
{
  INVARIANT(util::estNumeroVolValide(m_numero));
  INVARIANT(util::estNomValide(m_compagnie));
  INVARIANT(util::estFormat24HValide(m_heure));
  INVARIANT(util::estNomValide(m_ville));
}

} //namespace aerien