/**
 * \file Vol.h
 * \brief Fichier contenant la déclaration de la classe abstraite Vol
 * \author Rosalie Tremblay
 * \date 21 juin 2024, 13 h 00
 */

#include <string>
#include <memory>

/**
 *\namespace aerien
 * Contient les fonctions qui peuvent être utilisées par des objets Vol
 */
namespace aerien
{
  
#ifndef VOL_H
#define VOL_H
  
/**
 * \class Vol
 * \brief Classe Vol permettant à ses héritiers de modéliser les objets Vol
 */
class Vol
{
public:
  Vol (const std::string& p_numero,
       const std::string& p_compagnie, 
       const std::string& p_heure, 
       const std::string& p_ville);
  
  const std::string& reqNumero() const;
  const std::string& reqCompagnie() const;
  const std::string& reqHeure() const;
  const std::string& reqVille() const;
  
  void asgHeure(const std::string& p_heure);
  
  bool operator==(const Vol& p_vol);
  
  virtual std::string reqVolFormate() const;
  
  virtual std::unique_ptr<Vol> clone() const =0;
  
  virtual ~Vol (){};
  
private:
  std::string m_numero;
  std::string m_compagnie;
  std::string m_heure;
  std::string m_ville;
  
  void verifieInvariant() const;
};

#endif /* VOL_H */
} //namespace aerien
